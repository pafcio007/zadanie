package com.example.praktyki;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class PraktykiApplicationTests {

	@Test
	void contextLoads() {
	}

}
