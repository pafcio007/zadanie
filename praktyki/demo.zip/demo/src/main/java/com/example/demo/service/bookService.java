package com.example.demo.service;

import com.example.demo.entity.book;
import com.example.demo.repository.bookRepository;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.Id;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.Optional;

@Service
public class bookService {

    private final bookRepository BookRepository;

    public bookService(bookRepository BookRepository) {
        this.BookRepository = BookRepository;
    }

    public book getBookById(long id) {
        Optional<book> Book = BookRepository.findById(id);
        if (Book.isPresent()) {
            return Book.get();
        } else {
            return null;
        }
    }
}
