package com.example.demo.controller;

import com.example.demo.entity.book;
import com.example.demo.service.bookService;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequestMapping("/api/v1/book")
public class bookController {
    private final bookService bookService;

    public bookController(bookService bookService) {
        this.bookService = bookService;
    }

    @GetMapping("/{id}")
    public book getById(@PathVariable long id) {
        return bookService.getBookById(id);
    }
}
